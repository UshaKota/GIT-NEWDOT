
        #################################################################################################
        # This script is written to bring about the structure in the dataset for Coursolve/Need208
        # ref:https://www.coursolve.org/need/208?tab=home
        #The script does the foll:
        #1. Reads the csv form of data to structured data sets
        #2.creates ids for recommendation email treatment groups ref: CoursolveNeed-Emails-Info
        #3. Identifies the pattern of treatment email administered for each user
        #4. Creates a treatment group pattern for each learner record
        #5. The idea is to now monitor the participation based on each group of patterned subset of learners
        ###################################################################################################

        library(plyr)
        library(stringr)
        library(stringi)
        library(dplyr)

        library(lattice)
        library(scales)
        library(ggplot2)

        #read wk1 and wk3 data
        wk1_data<-read.csv("wk1_data.txt",row.names=NULL,col.names=c("anonymized_ID", "number_of_opens", "number_of_clicks", "greet_type", "body_type", "thread_type"))

        wk3_data<-read.csv("wk1_data.txt",row.names=NULL,col.names=c("anonymized_ID", "number_of_opens", "number_of_clicks", "greet_type", "body_type", "thread_type"))
        #make a greetings table and add column names

        greet_dt<-read.table("greet_labels.txt",row.names=NULL,col.names=c("greet_id","greet_type"))

        #make a body table and add column names

        body_dt<-read.table("body_labels.txt",row.names=NULL,col.names=c("body_id","body_type"))
        #make a content table  with thread types add column names
        thread_dt<-read.table("get_thread_labels.txt",row.names=NULL,col.names=c("thread_id","thread_type"))

        #merge data with greet,body, thread selection ids
        wk1_data$greet_label_id<-greet_dt[wk1_data$greet_type,1]
        wk1_data$body_label_id<-body_dt[wk1_data$body_type,1]
        wk1_data$thread_label_id<-thread_dt[wk1_data$thread_type,1]


        wk3_data$greet_label_id<-greet_dt[wk1_data$greet_type,1]
        wk3_data$body_label_id<-body_dt[wk1_data$body_type,1]
        wk3_data$thread_label_id<-thread_dt[wk1_data$thread_type,1]

        #drop lengthy label data columns - make the tables more numeric
        snip_cols <- c("greet_type","body_type","thread_type")
        wk1_data_snipd_cols <-wk1_data[,!(names(wk1_data) %in% snip_cols)]
        wk3_data_snipd_cols <-wk3_data[,!(names(wk3_data) %in% snip_cols)]

        #group learners by email administration patterns
        #[1,1,1],[1,1,2],[1,1,3] e.g. [1,1,1] pattern identified as = [prepare_greeting_html,prepare_body_html,get_threads_highest_reputation_participants]
        #group of emails administered to a user
        #[1,2,1],[1,2,2],[1,2,3]
        #[2,1,1],[2,1,2],[2,1,3]
        #[2,2,1],[2,2,2],[2,2,3]

        #create a pattern id to  which the users belong ranging from 1 -12 as [111] for reference
        pattern_df<-unique(wk1_data_snipd_cols[,c("greet_label_id","body_label_id","thread_label_id")])

        #now each user  belongs to one of the 12 email treatment patterns used to observe the change in participation
        trtmnt_grp_pattern<-do.call(paste, as.data.frame(wk1_data_snipd_cols[,c("greet_label_id","body_label_id","thread_label_id")], stringsAsFactors=FALSE))
        new_wk1_data<-cbind(wk1_data_snipd_cols,trtmnt_grp_pattern)
        new_wk3_data<-cbind(wk3_data_snipd_cols,trtmnt_grp_pattern)

        # so now we can compact the dataset by pattern of email adminisration

        again_snip_cols <- c("greet_label_id","body_label_id","thread_label_id")
        compact_wk1_data<-new_wk1_data[,!(names(new_wk1_data) %in% again_snip_cols)]
        compact_wk3_data<-new_wk3_data[,!(names(new_wk3_data) %in% again_snip_cols)]

        #start data subsetting based on the patterns and graph the data
        png("num_opens_wk1")

        #create a plot1 for average opens/avg.clicks per subset
        graph_data<-ggplot(data=compact_wk1_data, aes(x=trtmnt_grp_pattern, y=number_of_opens, group=trtmnt_grp_pattern, colour=trtmnt_grp_pattern)) +
                geom_line() +
                geom_point()
        graph_data<-graph_data + ggtitle("WK#1 Opens count - Treatment Group")

        print(graph_data)
        dev.off()

